from fastapi import FastAPI, HTTPException
from app.models import Task
from app.repository import TaskRepository
from fastapi.staticfiles import StaticFiles
from prometheus_fastapi_instrumentator import Instrumentator

app = FastAPI()
repo = TaskRepository()

@app.get("/")
def read_root():
    return {"message": "To-Do List Manager API is running."}

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.post("/tasks", response_model=Task)
def api_create_task(task: Task):
    try:
        return repo.create_task(task)
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))

@app.get("/tasks", response_model=list[Task])
def api_get_tasks():
    return repo.get_tasks()

@app.get("/tasks/{task_id}", response_model=Task)
def api_get_task(task_id: int):
    task = repo.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.put("/tasks/{task_id}", response_model=Task)
def api_update_task(task_id: int, updated_task: Task):
    task = repo.update_task(task_id, updated_task)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.delete("/tasks/{task_id}", response_model=dict)
def api_delete_task(task_id: int):
    if not repo.delete_task(task_id):
        raise HTTPException(status_code=404, detail="Task not found")
    return {"detail": "Task deleted successfully"}

app.mount("/static", StaticFiles(directory="static"), name="static")

Instrumentator().instrument(app).expose(app)
